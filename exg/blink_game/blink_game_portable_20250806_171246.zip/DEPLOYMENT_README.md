# EEG Blink-Controlled Game - Portable Version

This is a portable version of the EEG Blink-Controlled Game that can be run on any computer.

## Quick Start

### Windows:
1. Double-click `setup.bat` to install dependencies
2. Double-click `run_game.bat` to start the game

### Linux/Mac:
1. Run `./setup.sh` to install dependencies
2. Run `./run_game.sh` to start the game

## Manual Setup

If the automatic setup doesn't work:

1. Install Python 3.8+ from https://python.org
2. Open terminal/command prompt in this folder
3. Create virtual environment: `python -m venv blink_game_env`
4. Activate it:
   - Windows: `blink_game_env\Scripts\activate`
   - Linux/Mac: `source blink_game_env/bin/activate`
5. Install dependencies: `pip install -r requirements.txt`
6. Run the game: `python src/main.py`

## Game Features

- **Simulated Mode**: Uses realistic EEG data simulation for testing
- **Real Hardware Mode**: Can connect to Raspberry Pi Pico for real EEG input
- **Machine Learning**: Trained model detects blinks in real-time
- **Interactive Game**: Jump over obstacles by blinking!

## How to Play

1. Start the game using one of the methods above
2. Choose option 5 "Run the game" from the menu
3. The ball moves automatically from left to right
4. Blink (or press SPACE) to make the ball jump over red obstacles
5. Avoid collisions to keep playing and increase your score!

## Controls

- **Blink**: Make the ball jump (main control)
- **SPACE**: Manual jump (backup control)
- **B**: Trigger test blink (simulation mode only)
- **P**: Pause/unpause game
- **R**: Restart game (when game over)
- **Q**: Quit game

## Connecting Real Hardware

See `PICO_SETUP.md` for detailed instructions on connecting a Raspberry Pi Pico with EEG sensors.

To use real hardware:
```
python src/game_with_pico.py --pico --port COM3
```

## Troubleshooting

1. **Python not found**: Install Python 3.8+ from python.org
2. **Permission errors**: Run as administrator (Windows) or use sudo (Linux/Mac)
3. **Game won't start**: Check that all dependencies installed correctly
4. **No display**: Make sure you have a graphical environment (not SSH)

## System Requirements

- Python 3.8 or higher
- Windows 10+, macOS 10.14+, or Linux
- 4GB RAM minimum
- Graphics support for pygame
- USB port (if using real Pico hardware)

## Files Included

- `src/`: Source code files
- `data/`: EEG training datasets
- `models/`: Trained machine learning models
- `requirements.txt`: Python dependencies
- `README.md`: Main documentation
- `PICO_SETUP.md`: Hardware setup guide

Enjoy playing the EEG Blink-Controlled Game!
