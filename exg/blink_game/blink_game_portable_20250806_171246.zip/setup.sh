#!/bin/bash
echo "Setting up EEG Blink Game..."
echo

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.8+ from your package manager"
    exit 1
fi

echo "Python found, creating virtual environment..."
python3 -m venv blink_game_env

echo "Activating virtual environment..."
source blink_game_env/bin/activate

echo "Installing dependencies..."
pip install -r requirements.txt

echo
echo "Setup complete!"
echo
echo "To run the game:"
echo "1. Open terminal in this folder"
echo "2. Run: source blink_game_env/bin/activate"
echo "3. Run: python src/main.py"
echo
echo "Or run: ./run_game.sh"
echo
