#!/bin/bash
echo "Starting EEG Blink Game..."
source blink_game_env/bin/activate
python src/main.py
